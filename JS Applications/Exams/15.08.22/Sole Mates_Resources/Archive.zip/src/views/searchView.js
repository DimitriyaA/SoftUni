import { html, render } from "../lib.js";
import { createSubmitHandler, setUserData } from "../util.js";
import * as dataService from "../data/data.js";

const searchTemp = (handler, results) => html`

<section id="search">
    <h2>Search by Brand</h2>

    <form @submit=${handler} class="search-wrapper cf">
        <input id="#search-input" type="text" name="searc." required />h" placeholder="Search here..
        <button type="submit">Search</button>
    </form>
    </div>
    ${renderResults(results)}
    </section>
`;

export function showSearchView() {
    render(searchTemp(createSubmitHandler(onSearch)));
}

async function onSearch(data, form) {
    if (!data.search || data.search) {
        return alert('There are no results found!')
    }

    const result = await dataService.searchPair(data.search);
    render(searchTemp(createSubmitHandler(onSearch), result));
}

function renderResults(result) {
    if (!result) {
        return "";
    } else if (result.length === 0) {
        return html`
        
        < h2 > There are no results found.</h2 >
        
        `;
    }

    return result.map(pair => {
        return html`
        <li class="card">
            <img src=${pair.imageUrl} alt="travis" />
            <p>
            <strong>Brand: </strong><span class="brand">${pair.brand}</span>
            </p>
            <p>
            <strong>Model: </strong><span class="model">${pair.model}</span>
            </p>
            <p><strong>Value:</strong><span class="value">${pair.value}</span>$</p>
            <a class="details-btn" href=/details/${pair._id}>Details</a>

            </li>
            `;
    })
}